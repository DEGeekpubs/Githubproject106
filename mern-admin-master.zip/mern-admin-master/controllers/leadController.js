const methods = require("./crudController");
module.exports = methods.crudController("Lead");
